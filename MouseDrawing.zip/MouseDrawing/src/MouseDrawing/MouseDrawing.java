
package MouseDrawing;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class MouseDrawing extends Application {
    Path path;
    @Override
    public void start(Stage primaryStage) {
        Group root = new Group();
        
        Scene scene = new Scene(root,600,500);
       
        ColorPicker cp = new ColorPicker();
        cp.setOnAction(new EventHandler() {
            public void handle(Event t) {
                path.setStroke(cp.getValue());               
            }
        });
        Text text = new Text();
        text.setFont(new Font("sans-serif", 10));
        text.setLayoutX(120);
        text.setLayoutY(30);
        Slider s = new Slider();
        s.setOrientation(Orientation.HORIZONTAL);
        s.setLayoutX(120);
        s.setLayoutY(1);
        s.setMin(0);
        s.setMax(8);
        s.setShowTickMarks(true);
        s.setMajorTickUnit(1);
        s.setMinorTickCount(0);
        
        s.valueProperty().addListener((observable, oldvalue, newvalue) -> {
            int i = newvalue.intValue();
            text.setText(Integer.toString(i));
            path.setStrokeWidth(i);
        });
        
        path = new Path();
        path.setStrokeWidth(1);
        path.setStroke(cp.getValue());
        
        scene.setOnMouseClicked(mouseHandler);
        scene.setOnMouseDragged(mouseHandler);
        scene.setOnMouseEntered(mouseHandler);
        scene.setOnMouseExited(mouseHandler);
        scene.setOnMouseMoved(mouseHandler);
        scene.setOnMousePressed(mouseHandler);
        scene.setOnMouseReleased(mouseHandler);
        
        root.getChildren().addAll(path,cp,s,text);
        primaryStage.setTitle("Mouse drawing");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    EventHandler<MouseEvent> mouseHandler = new EventHandler<MouseEvent>(){
        @Override
        public void handle(MouseEvent mouseEvent){
            if(mouseEvent.getEventType() == MouseEvent.MOUSE_PRESSED){
                path.getElements().clear();
                path.getElements().add(new MoveTo(mouseEvent.getX(),mouseEvent.getY()));
            }else if(mouseEvent.getEventType() == MouseEvent.MOUSE_DRAGGED){
                path.getElements().add(new LineTo(mouseEvent.getX(),mouseEvent.getY()));
            }
        }
    };

    
    public static void main(String[] args) {
        launch(args);
    }
    
}
